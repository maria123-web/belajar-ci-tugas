<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Halaman Ini Produk
<?= $this->endSection() ?>